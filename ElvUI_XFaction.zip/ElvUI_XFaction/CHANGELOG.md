### Version 2.1.4 [ October/18th/2020 ]

**New Additions:**  

**Bug Fixes:**  
[Time Played] Fixed an issue with it being stuck on Waiting

**Misc. Changes:**  
