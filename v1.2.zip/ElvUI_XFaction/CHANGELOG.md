### Version 1.0 [ 05.31.2022 ]

**New Additions:**  
[XFaction] Alpha build that enables cross-faction guild chat and roster visibility on Proudmoore.
[Guild (X)] Alpha build that displays roster of all EK members running the addon on Proudmoore.
[Soulbind (X)] Alpha build, misc DT
[Shard (X)] Alpha build, misc DT
[WoWToken (X)] Alpha build, misc DT

**Bug Fixes:**  

**Misc. Changes:**  
